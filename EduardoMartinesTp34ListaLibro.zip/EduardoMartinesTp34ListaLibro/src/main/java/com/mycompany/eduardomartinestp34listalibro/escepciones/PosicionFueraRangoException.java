/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.eduardomartinestp34listalibro.escepciones;

/**
 *
 * @author Eduardo
 */
public class PosicionFueraRangoException extends Exception{
    public PosicionFueraRangoException() {
        super("La posicion es incorrecta");
    }

    public PosicionFueraRangoException(String message) {
        super(message);
    }
}
