
package com.mycompany.eduardomartinestp34listalibro;

import com.mycompany.eduardomartinestp34listalibro.escepciones.*;



/**
 * Interface que deben implementar las estructuras que se crean usando listas
 * enlazadas. Todos los m�todos de una interface son abstractos.
 */
public interface InterfaceLista<T> {
       /**
        * inicia la estructura
        */ 
       public void iniciar();
      
       /**
        * inserta un elemento al frente de la lista
        * @param dato - el elemento que se desea insertar al frente de la lista
        */
       public void insertar(T dato);

       /**
        * inserta un elemento al final de la lista
        * @param dato - el elemento que se desea insertar al final de la lista
        */
       public void insertarAtras(T dato);

       /**
       * inserta un elemento despues de un objeto pasado como parametro
       * si despuesDe no existe inserta al final de la lista
       * @param dato - el elemento que se desea insertar despuesDe
       * @param despuesDe - el elemento despues del que se quiere insertar el dato
       */
       public void insertar(T dato, T despuesDe);

       /**
        * inserta un elemento en la posicion pos, si pos no existe debe lanzar
        * PosicionFueraRangoException
        * @param dato - el elemento que se desea insertar
        * @param pos - la posici�n donde se quiere insertar
        * @throws PosicionFueraRangoException si pos no existe
        */
       public void insertar(T dato, int pos) throws PosicionFueraRangoException;

       /**
        * remueve un elemento del frente o lanza una excepci�n si la lista esta
        * vacia
        * @return el objeto eliminado
        * @throws ListaVaciaException
        */
       public T remover() throws ListaVaciaException;

       /**
        * remueve un elemento del final o lanza una excepci�n si la lista esta
        * vacia
        * @return el objeto eliminado
        * @throws ListaVaciaException si la lista esta vac�a
        */
       public T removerAtras() throws ListaVaciaException;

       /**
        * remueve el primer elemento (de la lista) que coincida con el dato 
        * recibido como par�metro o lanza una excepci�n si la lista esta vacia
        * o no encuentra el dato a remover.
        * @throws ListaVaciaException si la lista esta vac�a
        * @throws NoSuchElementException si no encuentra el dato a eliminar
        */
       public void remover(T dato) throws ListaVaciaException, 
                                               NoSuchElementException;

       /**
        * remueve un elemento de la posicion pos o lanza una excepcion si
        * pos esta fuera de rango (pos < 1 || pos > size())
        * @return el objeto eliminado
        * @throws ListaVaciaException si la lista esta vac�a
        * @throws PosicionFueraRangoException si no encuentra la pos a eliminar
       */
       public T remover(int pos) throws ListaVaciaException, 
                                             PosicionFueraRangoException;

       /**
        * busca un elemento y devuelve su ubicaci�n en la lista
        * @return 0 si no existe (o la lista esta vacia), o la posicion dentro 
        * de la lista si existe, siendo 1 el primer elemento
        */
       public int buscar(T dato);

       /**
        * Retorna el elemento ubicado en pos o lanza una excepcion si
        * pos esta fuera de rango (pos < 1 || pos > size())
        * @return el elemento en la posicion indicada
        * @throws PosicionFueraRangoException si no encuentra la pos a consultar
        */
       public T consultar(int pos) throws PosicionFueraRangoException;

       /**
        * retorna todos los datos de la lista como un vector de objetos
        * @return un vector de objetos con los elementos de la lista enlazada
        */
       public Object[] toArray();

       /**
       * verifica si la estructura esta o no vac�a
       * @return true si la estructura est� vac�a o false en caso contrario
       */
       public boolean isEmpty();
       
       /**
       * Retorna el numero de elementos en la lista enlazada.
       * @return el tamanho de la lista
       */
       public int size();

}
