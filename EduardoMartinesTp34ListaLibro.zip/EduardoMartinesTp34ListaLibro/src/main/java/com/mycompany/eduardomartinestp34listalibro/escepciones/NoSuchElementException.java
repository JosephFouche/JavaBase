/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.eduardomartinestp34listalibro.escepciones;

/**
 *
 * @author Eduardo
 */
public class NoSuchElementException extends Exception{
    public  NoSuchElementException() {
        super("El dato no existe");
        //System.out.println("El dato no existe");  error
    }

    public  NoSuchElementException(String message) {
        super(message);
    }
    
    
}
