/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.eduardomartinestp34listalibro;
import com.mycompany.eduardomartinestp34listalibro.escepciones.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Eduardo
 */
public class ListaLibro implements InterfaceLista<EduardoMartinesTp34ListaLibro>{
    private List<EduardoMartinesTp34ListaLibro> lista;

    public ListaLibro() {
        this.lista = new ArrayList<>();
    }
    @Override
    public void iniciar() {
        lista.clear();
    }

    @Override
    public void insertar(EduardoMartinesTp34ListaLibro dato) {
        lista.add(0, dato);
    }

    @Override
    public void insertarAtras(EduardoMartinesTp34ListaLibro dato) {
        lista.add(dato);
    }

    @Override
    public void insertar(EduardoMartinesTp34ListaLibro dato, EduardoMartinesTp34ListaLibro despuesDe) {
        int index = lista.indexOf(despuesDe);
        if (index == -1) {
            lista.add(dato);
        } else {
            lista.add(index + 1, dato);
        }
    }

    @Override
    public void insertar(EduardoMartinesTp34ListaLibro dato, int pos) throws PosicionFueraRangoException {
        if (pos < 1 || pos > lista.size() + 1) {
            throw new PosicionFueraRangoException("Posición fuera de rango.");
        }
        lista.add(pos - 1, dato);
    }

    @Override
    public EduardoMartinesTp34ListaLibro remover() throws ListaVaciaException {
        if (lista.isEmpty()) {
            throw new ListaVaciaException();
        }
        return lista.remove(0);
    }

    @Override
    public EduardoMartinesTp34ListaLibro removerAtras() throws ListaVaciaException {
        if (lista.isEmpty()) {
            throw new ListaVaciaException();
        }
        return lista.remove(lista.size() - 1);
    }

    @Override
    public void remover(EduardoMartinesTp34ListaLibro dato) throws ListaVaciaException, NoSuchElementException {
        if (lista.isEmpty()) {
            throw new ListaVaciaException();
        }
        if (!lista.remove(dato)) {
            throw new NoSuchElementException("El libro no se encuentra en la lista.");
        }
    }

    @Override
    public EduardoMartinesTp34ListaLibro remover(int pos) throws ListaVaciaException, PosicionFueraRangoException {
        if (lista.isEmpty()) {
            throw new ListaVaciaException();
        }
        if (pos < 1 || pos > lista.size()) {
            throw new PosicionFueraRangoException("Posición fuera de rango.");
        }
        return lista.remove(pos - 1);
    }

    @Override
    public int buscar(EduardoMartinesTp34ListaLibro dato) {
        int index = lista.indexOf(dato);
        return index == -1 ? 0 : index + 1;
    }

    @Override
    public EduardoMartinesTp34ListaLibro consultar(int pos) throws PosicionFueraRangoException {
        if (pos < 1 || pos > lista.size()) {
            throw new PosicionFueraRangoException("Posición fuera de rango.");
        }
        return lista.get(pos - 1);
    }

    @Override
    public Object[] toArray() {
        return lista.toArray();
    }

    @Override
    public boolean isEmpty() {
        return lista.isEmpty();
    }

    @Override
    public int size() {
        return lista.size();
    }
}
