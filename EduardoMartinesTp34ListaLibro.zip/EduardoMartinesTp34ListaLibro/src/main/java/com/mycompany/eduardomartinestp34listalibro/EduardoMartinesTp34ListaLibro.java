/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.eduardomartinestp34listalibro;

/**
 * 
 * 
 Crear una clase ListaLibro que implemente la InterfaceLista.java (disponible en Educa). Crear
una clase Libro con los siguientes datos el código del libro, el nombre, autor, número de
páginas, editorial, año, la categoría. Por medio de una Aplicación que permita a través de un
menú: 1) Insertar por teclado un libro, 2) Eliminar un libro (de cualquiera de las posibles
posiciones, usar un submenú) 3) Buscar e indicar si un libro está o no en la lista, 4) consultar
por una categoría determinada y listar los libros (si considera conveniente implemente la clase
categoría) 5) Mostrar la cantidad total de libros 6) almacenar la lista de libros en un archivo
INVENTARIO_LIBROS.TXT 7) Finalizar 
 * @author Eduardo
 */
public class EduardoMartinesTp34ListaLibro {

    private String codigo;
    private String nombre;
    private String autor;
    private int numeroPaginas;
    private String editorial;
    private int año;
    private String categoria;

    public EduardoMartinesTp34ListaLibro(String codigo, String nombre, String autor, int numeroPaginas, String editorial, int año, String categoria) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.autor = autor;
        this.numeroPaginas = numeroPaginas;
        this.editorial = editorial;
        this.año = año;
        this.categoria = categoria;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(int numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "EduardoMartinesTp34ListaLibro{" + "codigo=" + codigo + ", nombre=" + nombre + ", autor=" + autor + ", numeroPaginas=" + numeroPaginas + ", editorial=" + editorial + ", a\u00f1o=" + año + ", categoria=" + categoria + '}';
    }
    
    
    
}
