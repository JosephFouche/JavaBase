/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.eduardomartinestp34listalibro;
import com.mycompany.eduardomartinestp34listalibro.escepciones.*;

import java.io.*;
import java.util.Scanner;
/**
 *
 * @author Eduardo
 */
public class Aplicacion {
    private static ListaLibro listaLibros = new ListaLibro();
    private static Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args) {
        boolean salir = false;
        while (!salir) {
            mostrarMenu();
            int opcion = scanner.nextInt();
            scanner.nextLine();  // Consumir el salto de línea
            switch (opcion) {
                case 1:
                    insertarLibro();
                    break;
                case 2:
                    eliminarLibro();
                    break;
                case 3:
                    buscarLibro();
                    break;
                case 4:
                    //El método consultarPorCategoria recorrerá la lista de libros y mostrará aquellos que pertenezcan
                    //a la categoría especificada por el usuario.
                    consultarPorCategoria();
                    break;
                case 5:
                    //simplemente necesitamos contar la cantidad total de libros en la lista y mostrar ese número.
                    //La implementación es bastante directa ya que ya tenemos un método size()
                    //en nuestra clase de lista que devuelve el número de elementos.
                    mostrarCantidadTotal();
                    break;
                case 6:
                    //necesitamos escribir la lista de libros en un archivo de texto.
                    //Utilizaremos las clases FileWriter y BufferedWriter de Java para este propósito. 
                    //Cada libro será convertido a una cadena de texto utilizando su método toString() y luego escrito en el archivo.
                    almacenarEnArchivo();
                    break;
                case 7:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción inválida, intente nuevamente.");
            }
        }
    }
    private static void mostrarMenu() {
        System.out.println("1. Insertar libro");
        System.out.println("2. Eliminar libro");
        System.out.println("3. Buscar libro");
        System.out.println("4. Consultar por categoría");
        System.out.println("5. Mostrar cantidad total de libros");
        System.out.println("6. Almacenar lista de libros en archivo");
        System.out.println("7. Finalizar");
    }
    private static void insertarLibro() {
        System.out.println("Ingrese los datos del libro:");
        System.out.print("Código: ");
        String codigo = scanner.nextLine();
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Autor: ");
        String autor = scanner.nextLine();
        System.out.print("Número de páginas: ");
        int numeroPaginas = scanner.nextInt();
        scanner.nextLine();  // Consumir el salto de línea
        System.out.print("Editorial: ");
        String editorial = scanner.nextLine();
        System.out.print("Año: ");
        int año = scanner.nextInt();
        scanner.nextLine();  // Consumir el salto de línea
        System.out.print("Categoría: ");
        String categoria = scanner.nextLine();

        EduardoMartinesTp34ListaLibro libro = new EduardoMartinesTp34ListaLibro(codigo, nombre, autor, numeroPaginas, editorial, año, categoria);
        listaLibros.insertarAtras(libro);
        System.out.println("Libro insertado exitosamente.");
    }
    
    private static void eliminarLibro() {
        System.out.println("Seleccione la posición del libro a eliminar:");
        for (int i = 0; i < listaLibros.size(); i++) {
        try {
            System.out.println((i + 1) + ". " + listaLibros.consultar(i + 1).toString());
        } catch (PosicionFueraRangoException e) {
            // Esta excepción no debería ocurrir ya que estamos iterando dentro del rango
            System.out.println("Error interno: " + e.getMessage());
        }
    }
        int pos = scanner.nextInt();
        scanner.nextLine();  // Consumir el salto de línea
        try {
            listaLibros.remover(pos);
            System.out.println("Libro eliminado exitosamente.");
        } catch (ListaVaciaException | PosicionFueraRangoException e) {
            System.out.println(e.getMessage());
        }
    }
    
    private static void buscarLibro() {
        System.out.println("Ingrese el código del libro a buscar:");
        String codigo = scanner.nextLine();
       for (int i = 0; i < listaLibros.size(); i++) {
        try {
            EduardoMartinesTp34ListaLibro libro = listaLibros.consultar(i + 1);  // Consultamos una sola vez por iteración
            if (libro.getCodigo().equals(codigo)) {
                System.out.println("Libro encontrado: " + libro.toString());
                return;
            }
        } catch (PosicionFueraRangoException e) {
            System.out.println("Error interno: " + e.getMessage());
        }
    }
        System.out.println("Libro no encontrado.");
    }
    
    private static void consultarPorCategoria() {
        System.out.print("Ingrese la categoría a consultar: ");
        String categoria = scanner.nextLine();
        boolean encontrado = false;

        for (int i = 0; i < listaLibros.size(); i++) {
            try {
                EduardoMartinesTp34ListaLibro libro = listaLibros.consultar(i + 1);  // Posiciones basadas en 1
                if (libro.getCategoria().equalsIgnoreCase(categoria)) {
                    System.out.println(libro.toString());
                    encontrado = true;
                }
            } catch (PosicionFueraRangoException e) {
                System.out.println("Error interno: " + e.getMessage());
            }
        }

        if (!encontrado) {
            System.out.println("No se encontraron libros en la categoría: " + categoria);
        }
    }
    
    private static void mostrarCantidadTotal() {
        System.out.println("Cantidad total de libros: " + listaLibros.size());
    }
    private static void almacenarEnArchivo() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("INVENTARIO_LIBROS.TXT"))) {
            for (int i = 0; i < listaLibros.size(); i++) {
                try {
                    writer.write(listaLibros.consultar(i + 1).toString());
                    writer.newLine();
                } catch (PosicionFueraRangoException e) {
                    System.out.println("Error interno: " + e.getMessage());
                }
            }
            System.out.println("Lista de libros almacenada en INVENTARIO_LIBROS.TXT exitosamente.");
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }
}
